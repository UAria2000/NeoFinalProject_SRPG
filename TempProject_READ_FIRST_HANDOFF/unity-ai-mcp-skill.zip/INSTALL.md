# Unity AI MCP Skill Install

1. Extract this zip file.
2. Copy the `unity-ai-mcp` folder to `C:\Users\<USER>\.codex\skills\unity-ai-mcp`.
3. Restart VS Code/Codex.
4. In a new chat, ask Codex to use the `unity-ai-mcp` skill for this Unity project.

This skill does not enable Unity MCP tools by itself. The Unity MCP tools still need to be enabled in the client/tool settings.
