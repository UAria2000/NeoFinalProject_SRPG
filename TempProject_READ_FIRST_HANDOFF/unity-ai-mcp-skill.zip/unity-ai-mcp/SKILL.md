---
name: unity-ai-mcp
description: Operate and validate Unity projects through Unity MCP, Unity AI Assistant, editor commands, console logs, game-view captures, and local code edits. Use when Codex must inspect or modify a Unity project, run Unity editor actions, diagnose MCP/tool issues, verify play-mode behavior, create debug scenes, connect assets, or preserve team-repo hygiene while working with Unity.
---

# Unity AI MCP

## Operating Rules

- Work in Korean if the active project instructions require Korean.
- Prefer Unity MCP tools for editor state, play mode, console logs, scene/game-view capture, and editor commands.
- Use local shell for fast text/file search, build checks, and git inspection.
- Never commit, stage, push, reset, or revert unless the user explicitly asks.
- Treat `.meta`, `ProjectSettings`, `Packages`, generated captures, and temporary assets as high-risk. Do not stage or clean them casually.
- If original game scripts must be edited, make a backup first when the user or project policy requires it. Debug-only scripts can usually be edited without backups if the user has allowed that.
- Keep debug tooling isolated under paths such as `Assets/Scripts/Debug`, `Assets/Scenes/DebugBattle.unity`, `Assets/Prefabs/Effects/Debug`, and `.codex_tmp`.

## Startup Checklist

1. Confirm project root with `pwd` or Unity `GetProjectRoot`.
2. Check git state with `git status --short` before touching files.
3. Check Unity state with `Unity_ManageEditor GetState`.
4. If Unity MCP reports `Unity not detected (no fresh discovery files found)`, immediately retry `Unity_ManageEditor GetState`; transient discovery loss is common.
5. Read relevant code with `rg` first, then inspect narrow files.
6. Before editing, tell the user what you are changing and why.

## Search Patterns

Use these searches before changing Unity battle/debug systems:

```powershell
rg -n "class BattleManager|PrepareBattle|StartBattle|AllyFormation|EnemyFormation" Assets/Scripts/Battle -g "*.cs"
rg -n "currentLevel|levelGrowth|promotionRank|Promotion|GetMaxHP|DMG" Assets/Scripts -g "*.cs"
rg -n "BattleUnitView|PlayHit|Effect|Prefab|SkillEffect|hitEffect|castEffect" Assets/Scripts -g "*.cs"
rg -n "DebugBattleSceneController|DebugBattle" Assets/Scripts Assets/Scenes -g "*.cs" -g "*.unity"
```

## Editing Workflow

1. Scope the change to debug-only files when the user is testing combat, effects, or tooling.
2. Prefer partial classes or small helper files when a debug controller grows too large.
3. Use `apply_patch` for manual edits.
4. Avoid changing main battle scenes or production battle scripts unless the user explicitly asks.
5. If a main script must change, back it up first in a clearly named `.codex_tmp` backup folder.
6. Do not rely on Unity-generated `.meta` files as intended work unless the user explicitly wants asset import changes committed later.

## Unity MCP Verification

Use a tight verification loop:

1. Run `dotnet build <solution>.sln --no-restore` after C# edits.
2. Enter Play mode with `Unity_ManageEditor Play`.
3. Use `Unity_RunCommand` for deterministic editor-side checks.
4. Read console errors with `Unity_GetConsoleLogs` using `logTypes: "Error"`.
5. Stop Play mode with `Unity_ManageEditor Stop`.
6. Report exact verification facts, not only "works".

Do not use `System.Reflection` in `Unity_RunCommand` unless the tool permits it. If reflection is blocked, add a narrow `#if UNITY_EDITOR` debug helper method to debug-only scripts and call that helper.

## Game-View Capture

- Prefer project-provided capture helpers when available.
- Use timestamped captures for repeated checks.
- Keep only a small rolling set when adding capture code.
- Inspect generated screenshots with an image viewer tool, not by assumption.
- If a fixed capture file such as `.codex_tmp/captures/debugbattle_gameview.png` is overwritten, also create timestamped files for history.

## Play-Mode Cleanup

When implementing debug stop/reset behavior:

- Stop managed coroutines.
- Clear battle result or set it to a neutral setup state after returning to the debug panel.
- Clear target markers, selection state, and UI selection.
- Clear formations if the debug panel should show a fresh setup.
- Remove spawned `BattleUnitView`, floating text, and debug-only effect objects.
- In editor-only debug reset paths, `DestroyImmediate` may be appropriate so objects disappear before verification counts are checked.

## Level And Promotion Notes

Unity battle units may not scale from `currentLevel` alone. Check for fields like:

- `levelGrowthMaxHp`
- `levelGrowthDmg`
- `promotionRank`
- `promotionBonusPercentPerRank`

If debug battle generation creates `PartyMemberData`, fill the same runtime fields the production flow uses. For deterministic debug setup, use average growth per level rather than random growth unless the user asks for random rolls.

## Branch And Sharing Hygiene

- Keep debug work on a separate branch when the user wants optional sharing.
- Merge or rebase from `origin/main` into the debug branch to receive team updates.
- Keep debug assets in isolated paths to reduce conflicts.
- If the user wants local-only work, prefer `.git/info/exclude` over `.gitignore` so the rule does not affect the team repo.
- For selective sharing without GitHub branch visibility, create a zip or patch containing only debug files.

## Final Report

Include:

- Files changed.
- What was verified.
- Unity console error count.
- Whether Play mode was stopped.
- Whether commits/staging were avoided.
- Any remaining risk, especially `.meta`, dirty worktree, or main-script edits.
