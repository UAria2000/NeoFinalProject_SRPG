using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class SoldierCard : MonoBehaviour
{
    [Header("UI Elements")]
    public TextMeshProUGUI soldierNameText;
    public TextMeshProUGUI levelText;
    public Image portraitImage;
    public GameObject highlightObject;

    [Header("Settings")]
    public SoldierPortraitSettings portraitSettings; // �ν����Ϳ��� ���

    // 1. �� �κ��丮�� (RosterUnitSaveData Ȱ��)
    public void SetupCard(RosterUnitSaveData unitData)
    {
        // �̸� ����
        soldierNameText.text = string.IsNullOrEmpty(unitData.instanceDisplayNameOverride)
            ? unitData.unitDefinitionId
            : unitData.instanceDisplayNameOverride;

        levelText.text = $"Lv.{unitData.level}";

        // �ʻ�ȭ �ڵ� ���� (unitViewDefinitionName ���)
        if (portraitSettings != null)
        {
            portraitImage.sprite = portraitSettings.GetPortrait(unitData.unitViewDefinitionName);
        }

        SetHighlight(false);
    }

    // 2. ���� �Ź��� (ID ���ڿ� Ȱ��)
    public void SetupCard(string unitViewName, int price)
    {
        soldierNameText.text = unitViewName;
        levelText.text = $"{price:N0} GOLD";

        // �ʻ�ȭ �ڵ� ����
        if (portraitSettings != null)
        {
            portraitImage.sprite = portraitSettings.GetPortrait(unitViewName);
        }

        SetHighlight(false);
    }

    public void SetHighlight(bool isActive)
    {
        if (highlightObject != null) highlightObject.SetActive(isActive);
    }
}