using UnityEngine;
using System.Collections.Generic;

[CreateAssetMenu(fileName = "SoldierPortraitSettings", menuName = "Marketplace/Portrait Settings")]
public class SoldierPortraitSettings : ScriptableObject
{
    [System.Serializable]
    public struct PortraitEntry
    {
        public string viewDefinitionName; // RosterUnitSaveData�� unitViewDefinitionName�� ��ġ�ؾ� ��
        public Sprite portrait;           // ǥ�õ� �ʻ�ȭ ��������Ʈ
    }

    public List<PortraitEntry> portraitList = new List<PortraitEntry>();

    // ���� �˻��� ���� ��ųʸ� ��ȯ
    private Dictionary<string, Sprite> _portraitDict;

    public Sprite GetPortrait(string viewName)
    {
        if (_portraitDict == null)
        {
            _portraitDict = new Dictionary<string, Sprite>();
            foreach (var entry in portraitList)
            {
                if (!string.IsNullOrEmpty(entry.viewDefinitionName) && !_portraitDict.ContainsKey(entry.viewDefinitionName))
                    _portraitDict.Add(entry.viewDefinitionName, entry.portrait);
            }
        }

        if (_portraitDict.TryGetValue(viewName, out Sprite sprite))
            return sprite;

        return null; // �� ã�� ��� �⺻ �̹��� Ȥ�� null
    }
}