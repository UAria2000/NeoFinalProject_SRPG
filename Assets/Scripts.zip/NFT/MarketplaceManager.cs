using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using Unity.Services.Core;
using Unity.Services.Authentication;
using Unity.Services.CloudCode;
using Unity.Services.CloudSave;
using Unity.Services.Economy;
using Unity.Services.Economy.Model;

public class MarketplaceManager : MonoBehaviour
{
    [Serializable]
    public class MarketListing
    {
        public string listingId;
        public string sellerId;
        public string unitType;
        public string instanceId;
        public int price;
    }

    [Serializable]
    private class SerializationWrapper<T>
    {
        public List<T> items;
    }

    private async void Start()
    {
        await InitializeServicesAsync();
    }

    /// <summary>
    /// ����Ƽ ���� �ʱ�ȭ �� �͸� ����
    /// </summary>
    private async Task InitializeServicesAsync()
    {
        try
        {
            await UnityServices.InitializeAsync();
            if (!AuthenticationService.Instance.IsSignedIn)
            {
                await AuthenticationService.Instance.SignInAnonymouslyAsync();
                Debug.Log($"[Marketplace] Signed in as: {AuthenticationService.Instance.PlayerId}");
            }
        }
        catch (Exception e)
        {
            Debug.LogError($"[Marketplace] Initialization Failed: {e.Message}");
        }
    }

    #region Cloud Code ȣ�� (���� ���� ����)

    /// <summary>
    /// ���縦 �ŷ��ҿ� �Ǹ� ����մϴ�.
    /// </summary>
    public async Task ListUnitAsync(string unitInstanceId, int price)
    {
        try
        {
            var args = new Dictionary<string, object>
            {
                { "unitInstanceId", unitInstanceId },
                { "price", price }
            };

            await CloudCodeService.Instance.CallModuleEndpointAsync("Marketplace", "ListUnit", args);
            Debug.Log("[Marketplace] Unit listed successfully.");
        }
        catch (CloudCodeException e)
        {
            Debug.LogError($"[Marketplace] Listing failed: {e.Message}");
        }
    }

    /// <summary>
    /// ������ �ø� �Ź��� ����ϰ� ���縦 ȸ���մϴ�.
    /// </summary>
    public async Task CancelListingAsync(string listingId)
    {
        try
        {
            var args = new Dictionary<string, object> { { "listingId", listingId } };
            await CloudCodeService.Instance.CallModuleEndpointAsync("Marketplace", "CancelListing", args);
            Debug.Log("[Marketplace] Listing cancelled.");
        }
        catch (CloudCodeException e)
        {
            Debug.LogError($"[Marketplace] Cancellation failed: {e.Message}");
        }
    }

    /// <summary>
    /// �ŷ����� �Ź��� �����մϴ�.
    /// </summary>
    public async Task PurchaseUnitAsync(string listingId)
    {
        try
        {
            var args = new Dictionary<string, object> { { "listingId", listingId } };
            await CloudCodeService.Instance.CallModuleEndpointAsync("Marketplace", "PurchaseUnit", args);
            Debug.Log("[Marketplace] Purchase successful.");
        }
        catch (CloudCodeException e)
        {
            Debug.LogError($"[Marketplace] Purchase failed: {e.Message}");
        }
    }

    #endregion

    #region ������ ��ȸ (Cloud Save - LoadAsync ���)

    /// <summary>
    /// ���� �ŷ��ҿ� ��ϵ� ��� �Ź� ����� �����ɴϴ�.
    /// </summary>
    public async Task<List<MarketListing>> GetAllListingsAsync()
    {
        try
        {
            var keys = new HashSet<string> { "MARKET_LIST" };

            // �ٽ� ����: GetAsync -> LoadAsync (Unity 6 ȣȯ)
            var data = await CloudSaveService.Instance.Data.Player.LoadAsync(keys);

            if (data.TryGetValue("MARKET_LIST", out var item))
            {
                // JsonUtility�� �ֻ��� �迭�� �������� �����Ƿ� ���� ������ ����մϴ�.
                string json = "{\"items\":" + item.Value.GetAsString() + "}";
                return JsonUtility.FromJson<SerializationWrapper<MarketListing>>(json).items;
            }
        }
        catch (Exception e)
        {
            Debug.LogError($"[Marketplace] Failed to fetch listings: {e.Message}");
        }

        return new List<MarketListing>();
    }

    #endregion
}