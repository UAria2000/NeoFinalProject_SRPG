using UnityEngine;
using UnityEngine.UI;

[DisallowMultipleComponent]
public class BattleBackgroundController : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Image backgroundImage;
    [SerializeField] private Sprite fallbackBackground;

    [Header("Options")]
    [SerializeField] private bool preserveAspect = true;
    [SerializeField] private bool hideWhenMissing = false;

    public void ApplyBackground(Sprite sprite)
    {
        Sprite resolved = sprite != null ? sprite : fallbackBackground;

        if (backgroundImage == null)
            return;

        bool hasSprite = resolved != null;
        backgroundImage.sprite = resolved;
        backgroundImage.enabled = hasSprite || !hideWhenMissing;
        backgroundImage.preserveAspect = preserveAspect;

        if (backgroundImage.gameObject != null)
            backgroundImage.gameObject.SetActive(hasSprite || !hideWhenMissing);
    }

    public void ApplyBackground(WorldGenerationSettings settings, FactionType faction, WorldTileEventType eventType)
    {
        Sprite sprite = settings != null ? settings.GetRandomBattleBackground(faction, eventType) : null;
        ApplyBackground(sprite);
    }

    public void ClearBackground()
    {
        if (backgroundImage == null)
            return;

        backgroundImage.sprite = null;
        backgroundImage.enabled = !hideWhenMissing;
        if (backgroundImage.gameObject != null)
            backgroundImage.gameObject.SetActive(!hideWhenMissing);
    }
}
