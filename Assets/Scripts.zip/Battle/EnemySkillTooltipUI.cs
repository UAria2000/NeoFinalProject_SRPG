public class EnemySkillTooltipUI : SkillTooltipUI
{
}
