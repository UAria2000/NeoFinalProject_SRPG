using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class BattleViewManager : MonoBehaviour
{
    [SerializeField] private RectTransform viewRoot;
    [SerializeField] private RectTransform[] allyAnchors = new RectTransform[4];
    [SerializeField] private RectTransform[] enemyAnchors = new RectTransform[4];
    [SerializeField] private BattleUnitView defaultUnitViewPrefab;

    [Header("Floating Feedback")]
    [SerializeField] private BattleFloatingTextUI floatingTextPrefab;
    [SerializeField] private RectTransform floatingTextRoot;
    [SerializeField] private float defaultFloatingTextDuration = 1f;
    [SerializeField] private float defaultFloatingTextRiseDistance = 40f;
    [SerializeField] private Vector2 floatingTextOffset = new Vector2(0f, 80f);

    private readonly Dictionary<BattleUnit, BattleUnitView> unitViews = new Dictionary<BattleUnit, BattleUnitView>();

    public void CreateView(BattleUnit unit, BattleInputController inputController)
    {
        if (unit == null || viewRoot == null)
            return;

        BattleUnitView prefab = unit.ViewDefinition != null && unit.ViewDefinition.viewPrefab != null
            ? unit.ViewDefinition.viewPrefab
            : defaultUnitViewPrefab;

        if (prefab == null)
        {
            Debug.LogWarning("[BattleViewManager] Missing defaultUnitViewPrefab.");
            return;
        }

        BattleUnitView view = Instantiate(prefab, viewRoot);
        view.Initialize(unit, GetSlotLabel(unit.Team, unit.SlotIndex));
        view.SetPositionInstant(GetAnchorAnchoredPosition(unit.Team, unit.SlotIndex));

        view.ConfigureClickHandling(inputController);

        unitViews[unit] = view;
    }

    public BattleUnitView GetView(BattleUnit unit)
    {
        if (unit == null) return null;
        BattleUnitView view;
        unitViews.TryGetValue(unit, out view);
        return view;
    }

    public IEnumerable<BattleUnitView> GetAllViews()
    {
        return unitViews.Values;
    }


    public void ClearAllViews()
    {
        foreach (KeyValuePair<BattleUnit, BattleUnitView> pair in unitViews)
        {
            if (pair.Value != null)
                Destroy(pair.Value.gameObject);
        }

        unitViews.Clear();
    }

    public void RemoveView(BattleUnit unit)
    {
        if (unit == null) return;
        BattleUnitView view;
        if (unitViews.TryGetValue(unit, out view))
        {
            if (view != null)
                Destroy(view.gameObject);
            unitViews.Remove(unit);
        }
    }

    public Vector2 GetAnchorAnchoredPosition(TeamType team, int slotIndex)
    {
        RectTransform[] anchors = team == TeamType.Ally ? allyAnchors : enemyAnchors;
        if (anchors == null || slotIndex < 0 || slotIndex >= anchors.Length || anchors[slotIndex] == null)
            return Vector2.zero;

        RectTransform anchor = anchors[slotIndex];
        if (viewRoot != null && anchor.parent == viewRoot)
            return anchor.anchoredPosition;

        if (viewRoot != null)
        {
            Vector3 local = viewRoot.InverseTransformPoint(anchor.position);
            return new Vector2(local.x, local.y);
        }

        return anchor.anchoredPosition;
    }

    public Vector3 GetAnchorPosition(TeamType team, int slotIndex)
    {
        RectTransform[] anchors = team == TeamType.Ally ? allyAnchors : enemyAnchors;
        if (anchors == null || slotIndex < 0 || slotIndex >= anchors.Length || anchors[slotIndex] == null)
            return viewRoot != null ? viewRoot.position : Vector3.zero;

        return anchors[slotIndex].position;
    }

    public void RefreshAllPositionsInstant(BattleFormation allyFormation, BattleFormation enemyFormation)
    {
        RefreshFormationPositionsInstant(allyFormation, TeamType.Ally);
        RefreshFormationPositionsInstant(enemyFormation, TeamType.Enemy);
    }

    public IEnumerator AnimateRefreshAllPositions(BattleFormation allyFormation, BattleFormation enemyFormation, float duration)
    {
        List<IEnumerator> routines = new List<IEnumerator>();
        AddFormationMoveRoutines(routines, allyFormation, TeamType.Ally, duration);
        AddFormationMoveRoutines(routines, enemyFormation, TeamType.Enemy, duration);

        for (int i = 0; i < routines.Count; i++)
            StartCoroutine(routines[i]);

        yield return new WaitForSeconds(duration);
    }

    private void AddFormationMoveRoutines(List<IEnumerator> routines, BattleFormation formation, TeamType team, float duration)
    {
        if (formation == null) return;
        List<BattleUnit> units = formation.GetAllUnits();
        for (int i = 0; i < units.Count; i++)
        {
            BattleUnit unit = units[i];
            BattleUnitView view = GetView(unit);
            if (view == null) continue;
            routines.Add(view.MoveToPosition(GetAnchorAnchoredPosition(team, unit.SlotIndex), duration));
        }
    }

    private void RefreshFormationPositionsInstant(BattleFormation formation, TeamType team)
    {
        if (formation == null) return;
        List<BattleUnit> units = formation.GetAllUnits();
        for (int i = 0; i < units.Count; i++)
        {
            BattleUnitView view = GetView(units[i]);
            if (view != null)
                view.SetPositionInstant(GetAnchorAnchoredPosition(team, units[i].SlotIndex));
        }
    }

    public void ClearAllMarkers()
    {
        foreach (KeyValuePair<BattleUnit, BattleUnitView> pair in unitViews)
        {
            if (pair.Value == null) continue;
            pair.Value.SetTurnMark(false);
            pair.Value.SetTargetMark(false);
            pair.Value.SetSelectableHighlight(false);
            pair.Value.SetHighlighted(false);
            pair.Value.SetHoverHighlight(false);
            pair.Value.SetCurrentTurnHighlight(false);
        }
    }

    public void SetTurnMarker(BattleUnit currentUnit)
    {
        foreach (KeyValuePair<BattleUnit, BattleUnitView> pair in unitViews)
        {
            if (pair.Value == null) continue;
            pair.Value.SetTurnMark(pair.Key == currentUnit);
        }
    }

    public void SetTargetMarkers(List<BattleUnit> units)
    {
        ClearTargetMarkers();
        if (units == null) return;

        for (int i = 0; i < units.Count; i++)
        {
            BattleUnitView view = GetView(units[i]);
            if (view != null)
            {
                view.SetTargetMark(true);
                view.SetSelectableHighlight(true);
            }
        }
    }

    public void ClearTargetMarkers()
    {
        foreach (KeyValuePair<BattleUnit, BattleUnitView> pair in unitViews)
        {
            if (pair.Value != null)
            {
                pair.Value.SetTargetMark(false);
                pair.Value.SetSelectableHighlight(false);
            }
        }
    }


    public void SetSelectableHighlights(List<BattleUnit> units)
    {
        ClearSelectableHighlights();
        if (units == null)
            return;

        for (int i = 0; i < units.Count; i++)
        {
            BattleUnitView view = GetView(units[i]);
            if (view != null)
                view.SetSelectableHighlight(true);
        }
    }

    public void ClearSelectableHighlights()
    {
        foreach (KeyValuePair<BattleUnit, BattleUnitView> pair in unitViews)
        {
            if (pair.Value != null)
                pair.Value.SetSelectableHighlight(false);
        }
    }

    public void SetHoverHighlight(BattleUnit unit)
    {
        foreach (KeyValuePair<BattleUnit, BattleUnitView> pair in unitViews)
        {
            if (pair.Value != null)
                pair.Value.SetHoverHighlight(pair.Key == unit);
        }
    }

    public void ClearHoverHighlight()
    {
        SetHoverHighlight(null);
    }

    public void PlayEffect(GameObject prefab, Vector3 worldPosition, float duration = 2f)
    {
        PlayEffect(prefab, worldPosition, duration, false);
    }

    public void PlayEffect(GameObject prefab, Vector3 worldPosition, float duration, bool mirrorX)
    {
        if (prefab == null || viewRoot == null) return;

        GameObject effect = Instantiate(prefab, viewRoot);
        effect.transform.position = worldPosition;
        if (mirrorX)
        {
            Vector3 scale = effect.transform.localScale;
            scale.x = -Mathf.Abs(scale.x);
            effect.transform.localScale = scale;
        }

        if (effect.TryGetComponent(out BattleRichHitEffectUI richEffect))
        {
            richEffect.SetDuration(duration);
            Vector2 spawnOffset = richEffect.SpawnOffset;
            if (mirrorX)
                spawnOffset.x = -spawnOffset.x;

            RectTransform rect = effect.GetComponent<RectTransform>();
            if (rect != null)
                rect.anchoredPosition += spawnOffset;
            else
                effect.transform.position += new Vector3(spawnOffset.x, spawnOffset.y, 0f);
        }

        Destroy(effect, duration);
    }

    public void PlayEffect(GameObject prefab, BattleUnitView targetView, float duration = 2f)
    {
        if (targetView == null)
            return;

        PlayEffect(prefab, targetView.HitEffectAnchorPosition, duration);
    }

    public void ShowFloatingText(BattleUnit unit, string text, Color color, float duration = -1f)
    {
        if (unit == null || string.IsNullOrWhiteSpace(text))
            return;

        BattleFloatingTextUI floating = CreateAndPositionFloatingText(unit, false);
        if (floating == null)
            return;

        floating.Play(text, color, duration > 0f ? duration : defaultFloatingTextDuration, defaultFloatingTextRiseDistance);
    }

    public void ShowFloatingTextParts(BattleUnit unit, string title, string value, Color titleColor, Color valueColor, float duration = -1f)
    {
        if (unit == null)
            return;
        if (string.IsNullOrWhiteSpace(title) && string.IsNullOrWhiteSpace(value))
            return;

        BattleFloatingTextUI floating = CreateAndPositionFloatingText(unit, true);
        if (floating == null)
            return;

        floating.PlaySeparated(title, value, titleColor, valueColor, duration > 0f ? duration : defaultFloatingTextDuration, defaultFloatingTextRiseDistance);
    }

    private BattleFloatingTextUI CreateAndPositionFloatingText(BattleUnit unit, bool separatedFallback)
    {
        BattleUnitView unitView = GetView(unit);
        if (unitView == null)
            return null;

        RectTransform parent = floatingTextRoot != null ? floatingTextRoot : viewRoot;
        if (parent == null)
            return null;

        BattleFloatingTextUI floating = CreateFloatingTextInstance(parent, separatedFallback);
        if (floating == null)
            return null;

        RectTransform floatingRect = floating.GetComponent<RectTransform>();
        RectTransform anchor = unitView.HoverAnchor;
        if (floatingRect != null && anchor != null)
        {
            Vector3 world = anchor.position;
            Vector3 local = parent.InverseTransformPoint(world);
            floatingRect.anchoredPosition = new Vector2(local.x, local.y) + floatingTextOffset;
        }

        return floating;
    }

    private BattleFloatingTextUI CreateFloatingTextInstance(RectTransform parent, bool separatedFallback)
    {
        if (floatingTextPrefab != null)
            return Instantiate(floatingTextPrefab, parent);

        GameObject go = new GameObject("BattleFloatingText", typeof(RectTransform), typeof(CanvasGroup));
        go.transform.SetParent(parent, false);

        RectTransform rootRect = go.GetComponent<RectTransform>();
        if (rootRect != null)
            rootRect.sizeDelta = new Vector2(260f, 80f);

        BattleFloatingTextUI floating = go.AddComponent<BattleFloatingTextUI>();

        if (separatedFallback)
        {
            VerticalLayoutGroup layout = go.AddComponent<VerticalLayoutGroup>();
            layout.childAlignment = TextAnchor.MiddleCenter;
            layout.childControlWidth = true;
            layout.childControlHeight = false;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = false;
            layout.spacing = 2f;
            layout.padding = new RectOffset(0, 0, 0, 0);

            TMP_Text skillText = CreateFallbackFloatingTextChild(go.transform, "SkillNameText", 21f, FontStyles.Normal);
            TMP_Text valueText = CreateFallbackFloatingTextChild(go.transform, "DamageText", 34f, FontStyles.Bold);
            floating.BindSeparated(skillText, valueText, go.GetComponent<CanvasGroup>());
        }
        else
        {
            TMP_Text tmp = go.AddComponent<TextMeshProUGUI>();
            tmp.alignment = TextAlignmentOptions.Center;
            tmp.fontSize = 28f;
            tmp.raycastTarget = false;
            tmp.richText = true;
            floating.Bind(tmp, go.GetComponent<CanvasGroup>());
        }

        return floating;
    }

    private TMP_Text CreateFallbackFloatingTextChild(Transform parent, string objectName, float fontSize, FontStyles fontStyle)
    {
        GameObject child = new GameObject(objectName, typeof(RectTransform));
        child.transform.SetParent(parent, false);

        RectTransform rect = child.GetComponent<RectTransform>();
        if (rect != null)
            rect.sizeDelta = new Vector2(260f, Mathf.Max(24f, fontSize + 8f));

        TMP_Text tmp = child.AddComponent<TextMeshProUGUI>();
        tmp.alignment = TextAlignmentOptions.Center;
        tmp.fontSize = fontSize;
        tmp.fontStyle = fontStyle;
        tmp.raycastTarget = false;
        tmp.richText = true;
        return tmp;
    }

    public void RefreshBattleVisualStates(BattleManager manager)
    {
        if (manager == null)
            return;

        foreach (KeyValuePair<BattleUnit, BattleUnitView> pair in unitViews)
        {
            BattleUnit unit = pair.Key;
            BattleUnitView view = pair.Value;
            if (unit == null || view == null)
                continue;

            bool isCurrent = manager.CurrentActingUnit == unit &&
                             manager.CurrentState != TurnState.ExecutingAction &&
                             manager.CurrentState != TurnState.BattleEnded &&
                             manager.InputMode != BattleInputMode.None;
            bool isInfoSelected = manager.SelectedAllyInfoUnit == unit || manager.SelectedEnemyInfoUnit == unit;
            bool isFinished = manager.HasUnitFinishedTurnThisRound(unit);

            // Upcoming/finished gray overlays are deprecated.
            // A unit that already ended its turn this round uses its dead battle sprite until the next round starts.
            view.RefreshBattleVisualState(isCurrent, isInfoSelected, isFinished);
        }
    }

    private string GetSlotLabel(TeamType team, int slotIndex)
    {
        string prefix = team == TeamType.Ally ? "A" : "E";
        return string.Format("{0}{1}", prefix, slotIndex + 1);
    }
}
