using System;
using System.Collections.Generic;

[Serializable]
public class ActiveWorldRunSaveData
{
    public string ownerAccountId;
    public bool hasActiveWorld;

    public int worldSeed;
    public string difficultyId;
    public int mapRadius;
    public int worldNumber;
    public int worldStartMainCharacterLevel;
    public bool isTutorialWorld;
    public int tutorialShownStepMask;
    public long createdUnixTime;

    public int currentTileId = -1;
    public int selectedTileId = -1;

    public List<WorldTileSaveData> tiles = new List<WorldTileSaveData>();
    public List<WorldQuestSaveData> activeQuests = new List<WorldQuestSaveData>();

    public List<WorldInventoryItemSaveData> worldInventory = new List<WorldInventoryItemSaveData>();
    public List<WorldEquipmentItemSaveData> worldEquipments = new List<WorldEquipmentItemSaveData>();
    public List<WorldEquipmentAssignmentSaveData> equipmentAssignments = new List<WorldEquipmentAssignmentSaveData>();

    public List<CapturedPrisonerSaveData> prisoners = new List<CapturedPrisonerSaveData>();
    public string sharedConsumableItemId;

    public int currentMana;
    public int maxMana;
    public int worldEarnedSoulAlreadyGranted;

    public int settlementBattleCount;
    public int settlementVictoryCount;
    public int settlementDefeatCount;
    public int settlementKilledEnemyCount;
    public int settlementCompletedQuestCount;
    public int settlementCapturedEnemyCount;
    public List<CapturedPrisonerSaveData> settlementCapturedPrisonerRecords = new List<CapturedPrisonerSaveData>();

    public List<WorldPartyMemberRuntimeSaveData> worldPartyMembers = new List<WorldPartyMemberRuntimeSaveData>();
}
